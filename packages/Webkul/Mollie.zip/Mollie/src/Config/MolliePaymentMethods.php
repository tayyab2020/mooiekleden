<?php
return [
    'molliePayment' => [
        'code' => 'molliePayment',
        'title' => 'Mollie Payment',
        'description' => 'Mollie Payment',
        'class' => 'Webkul\Mollie\Payment\Molliepayment',
        'active' => true,
        'sort'=> 5,
    ]
];