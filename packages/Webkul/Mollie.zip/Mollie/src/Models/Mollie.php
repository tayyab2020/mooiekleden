<?php

namespace Webkul\Mollie\Models;


use Illuminate\Database\Eloquent\Model;
use Webkul\Mollie\Contracts\Mollie as MollieContract;

class Mollie extends Model implements MollieContract
{
   
         
}