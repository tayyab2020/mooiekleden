<?php

namespace Webkul\Mollie\Models;

use Konekt\Concord\Proxies\ModelProxy;

class MollieProxy extends ModelProxy
{

}