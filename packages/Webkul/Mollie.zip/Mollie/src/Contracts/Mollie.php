<?php

namespace Webkul\Mollie\Contracts;

interface Mollie
{
    
}